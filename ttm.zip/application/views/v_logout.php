<form action="<?php echo base_url()."Auth/logout"; ?>" method="POST">
	<?php echo $pangkat_divisi." ".$divisi."<br>"; ?>
	<button type="sumbit">Logout</button>
</form>