<html>
<head><?php echo $map['js']; ?></head>
<body>
  <input type="text" id="myPlaceTextBox" />
  <?php echo $map['html']; ?>
</body>
</html>