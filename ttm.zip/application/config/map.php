<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['default_lat'] = '-7.952440099999998';
$config['default_lng'] = '112.6129181';
